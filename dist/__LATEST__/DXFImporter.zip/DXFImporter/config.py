from os.path import dirname, abspath
app_path = dirname(abspath(__file__))

app_name = 'DXFImporter'
company_name = "Autodesk"
