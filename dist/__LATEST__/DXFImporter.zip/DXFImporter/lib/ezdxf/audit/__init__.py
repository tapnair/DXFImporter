# Purpose: DXF audit package
# Created: 10.03.2017
# Copyright (C) 2017, Manfred Moitzi
# License: MIT License
from ezdxf.audit.auditor import Auditor, AuditError
