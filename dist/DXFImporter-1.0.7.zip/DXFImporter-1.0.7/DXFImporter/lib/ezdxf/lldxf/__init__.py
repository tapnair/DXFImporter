# Purpose: low level DXF modules
# Created: 16.07.2015
# Copyright (C) 2015, Manfred Moitzi
# License: MIT License
