"""DXFImporter - Import a folder of dxf files and create a component layout in Fusion 360"""

__version__ = '0.1.0'
__author__ = 'Patrick Rainsberry <patrick.rainsberry@autodesk.com>'
__all__ = []